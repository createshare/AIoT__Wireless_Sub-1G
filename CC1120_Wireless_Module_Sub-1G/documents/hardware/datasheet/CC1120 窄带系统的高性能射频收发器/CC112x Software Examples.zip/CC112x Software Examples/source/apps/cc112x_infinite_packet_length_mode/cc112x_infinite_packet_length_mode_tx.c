/*******************************************************************************
  Filename	:       cc112x_infinite_packet_length_mode_tx.c
  
  Description:      This examples shows how on can transmit packets with length
                    byte greater than 255 and and less than/or equal to 
                    PACKET_LENGTH. The example runs with all typical settings
                    from SmartRF Studio.
                    The packets are on the follwoing format:
                    ------------------------------------------------------------
                    preamble | sync | 2 length bytes | payload | 2 bytes CRC |
                    ------------------------------------------------------------
  
*******************************************************************************/


/******************************************************************************
* INCLUDES
*/
#include  <msp430.h>
#include "hal_board.h"
#include "hal_mcu.h"
#include "hal_led_trxeb.h"
#include "hal_button_trxeb.h"
#include "lcd_dogm128_6.h"   
#include "hal_spi_rf_trxeb.h"
#include "hal_int_rf_trxeb.h"
#include "cc112x_spi.h"
#include "cc112x_infinite_packet_length_mode_reg_config.h"
#include "stdlib.h"


/*******************************************************************************
* DEFINES
*/
#define PACKET_LENGTH               500     // Must be a number between 
//                                          // 256 and 2^16
#define FIFO_SIZE                   128
#define CRC_OK                      0x80 
#define AVAILABLE_BYTES_IN_TX_FIFO  122     // # of bytes one can write to the 
                                            // TX_FIFO when a falling edge occur
                                            // on IOCFGx = 0x02 and 
                                            // FIFO_THR = 120
#define BYTES_IN_TX_FIFO            (FIFO_SIZE - AVAILABLE_BYTES_IN_TX_FIFO)
#define INFINITE                    0
#define FIXED                       1
#define MAX_VARIABLE_LENGTH         255
#define INFINITE_PACKET_LENGTH_MODE 0x40
#define FIXED_PACKET_LENGTH_MODE    0x00


/*******************************************************************************
* LOCAL VARIABLES
*/
static uint8 txBuffer[PACKET_LENGTH + 2];   // Buffer used to hold the packet
                                            // to be sent
static uint8 packetSent = FALSE;            // Flag set when packet is sent
static uint16 packetCounter = 0;            // Counter keeping track of
                                            // packets sent
static uint16 packetLength = PACKET_LENGTH; // Length byte inserted in two first
                                            // bytes of the TX FIFO
static uint32 bytesLeft;                    // Keeping track of bytes left to 
                                            // write to the TX FIFO
static uint8 fixedPacketLength;
static uint8 *pBufferIndex;                 // Pointer to current position in 
                                            // the txBuffer 
static uint8 iterations;                    // For packets greater than 128 
                                            // bytes, this variable is used to
                                            // keep track of how many time the 
                                            // TX FIFO should be re-filled to
                                            // its limit 
static uint8 writeRemainingDataFlag;        // When this flag is set, the 
                                            // TX FIFO should not be filled
                                            // entirely
static uint8 pktFormat = INFINITE;


/*******************************************************************************
* STATIC FUNCTIONS
*/
static void initMCU(void);
static void registerConfig(void);
static void manualCalibration(void);
static void updateLcd(void);
static void packetSentISR(void);
static void txFifoBelowThresholdISR(void);
static void printWelcomeMessage(void);


/*******************************************************************************
 * @fn          main
 *
 * @brief       Runs the main routine
 *                
 * @param       none
 *
 * @return      none
 */
void main(void) {

    uint8 writeByte;
  
    // Initialize MCU and peripherals
    initMCU();
    
    // Write radio registers (typical settings from SmartRF Studio)
    registerConfig();

    // Application specific registers
    // FIFO_THR = 120
    // GPIO0 = TXFIFO_THR
    // GPIO2 = PKT_SYNC_RXTX
    writeByte = INFINITE_PACKET_LENGTH_MODE;
    cc112xSpiWriteReg(CC112X_PKT_CFG0, &writeByte, 1);
    writeByte = 0x78; cc112xSpiWriteReg(CC112X_FIFO_CFG, &writeByte, 1);
    writeByte = 0x02; cc112xSpiWriteReg(CC112X_IOCFG0,   &writeByte, 1);
    writeByte = 0x06; cc112xSpiWriteReg(CC112X_IOCFG2,   &writeByte, 1);

    // Calibrate the radio according to the errata note
    manualCalibration();

    // Set up and enable interrupt on GPIO0 (TXFIFO_THR)
    trxIsrConnect(GPIO_0, FALLING_EDGE, &txFifoBelowThresholdISR);
    trxEnableInt(GPIO_0);

    // Set up and enable interrupt on GPIO2 (PKT_SYNC_RXTX)
    trxIsrConnect(GPIO_2, FALLING_EDGE, &packetSentISR);
    trxEnableInt(GPIO_2);

    // Create data packet
    txBuffer[0] = (uint8)(packetLength >> 8);
    txBuffer[1] = (uint8)(packetLength & 0x00FF);
    for (uint16 i = 2; i < PACKET_LENGTH + 2; i++)
        txBuffer[i] = rand();

    printWelcomeMessage();

    // Infinite loop
    while(TRUE) {

        // Wait for button push
        while (!halButtonsPushed()); 

        // Transmit 1000 packets
        for (uint16 i = 0; i < 1000; i++) {

            // Set infinite packet length mode
            writeByte = INFINITE_PACKET_LENGTH_MODE;
            cc112xSpiWriteReg(CC112X_PKT_CFG0, &writeByte, 1);
            pktFormat = INFINITE;
            
            // Update variables
            writeRemainingDataFlag = FALSE;
            bytesLeft = packetLength + 2;
            pBufferIndex = txBuffer + FIFO_SIZE;
            iterations = (bytesLeft / AVAILABLE_BYTES_IN_TX_FIFO) - 1;
            fixedPacketLength = bytesLeft % (MAX_VARIABLE_LENGTH + 1);
            
            // Configure the PKT_LEN register
            writeByte = fixedPacketLength;
            cc112xSpiWriteReg(CC112X_PKT_LEN, &writeByte, 1);
            
            // Fill up the TX FIFO
            cc112xSpiWriteTxFifo(txBuffer, FIFO_SIZE);
            
            bytesLeft -= FIFO_SIZE;

            // Enter TX mode
            trxSpiCmdStrobe(CC112X_STX);

            trxClearIntFlag(GPIO_0);
            trxEnableInt(GPIO_0);

            // Wait for packet to be sent
            while (!packetSent);
            packetSent = FALSE;

            // Update LCD
            updateLcd();

            halMcuWaitMs(300);
        }
    } 
}


/*******************************************************************************
* @fn           printWelcomeMessage
*
* @brief       
*
* @param        none
*
* @return       none
*/
static void printWelcomeMessage(void) {
    lcdBufferClear(0);
    lcdBufferPrintString(0, "Inf. Pkt. Length Mode", 0, 0);
    lcdBufferSetHLine(0, 0, LCD_COLS - 1, 7); 
    lcdBufferPrintString(0, "Press a button", 0, 2);
    lcdBufferPrintString(0, "to start", 0, 3);
    lcdBufferPrintString(0, "Packet TX", 0, 7);
    lcdBufferSetHLine(0, 0, LCD_COLS - 1, 55);
    lcdBufferInvertPage(0, 0, LCD_COLS, 7);
    lcdSendBuffer(0);
}


/*******************************************************************************
* @fn          packetSentISR
*
* @brief       Function running every time a packet has been sent
*
* @param       none
*
* @return      none
*/
static void packetSentISR(void) {
    packetSent = TRUE;
    trxClearIntFlag(GPIO_2);
}


/*******************************************************************************
* @fn          txFifoBelowThresholdISR
*
* @brief       Function running every time the TX FIFO is drained below
*              127 - FIFO_THR = 127 - 120 = 7
*
* @param       none
*
* @return      none
*/
static void txFifoBelowThresholdISR(void) {

    uint8 writeByte;

    if (writeRemainingDataFlag) { // Less than 120 bytes to write to the TX FIFO
        cc112xSpiWriteTxFifo(pBufferIndex, bytesLeft);  // Write remaining bytes 
                                                        // to the TX FIFO
        trxDisableInt(GPIO_0);
        
    } else { // Fill up the TX FIFO
        cc112xSpiWriteTxFifo(pBufferIndex, AVAILABLE_BYTES_IN_TX_FIFO); 

        // Change to fixed packet length mode when there is less than 256 bytes 
        // left to transmit
        if ((bytesLeft < (MAX_VARIABLE_LENGTH + 1 - BYTES_IN_TX_FIFO)) && (pktFormat == INFINITE)) {
            writeByte = FIXED_PACKET_LENGTH_MODE; cc112xSpiWriteReg(CC112X_PKT_CFG0, &writeByte, 1);
            pktFormat = FIXED;
        }

        // Update the variables keeping track of how many more bytes should be 
        // written to the TX FIFO and where in txBuffer data should be taken from
        pBufferIndex += AVAILABLE_BYTES_IN_TX_FIFO;
        bytesLeft -= AVAILABLE_BYTES_IN_TX_FIFO;
    
        if (!(--iterations))
            writeRemainingDataFlag = TRUE;
    }

    trxClearIntFlag(GPIO_0);
}


/*******************************************************************************
 * @fn          updateLcd
 *
* @brief       Updates the LCD with # of packets sent
 *                
 * @param       none
 *
 * @return      none
 */
static void updateLcd(void) {
    lcdBufferClear(0);
    lcdBufferPrintString(0, "Inf. Pkt. Length Mode", 0, 0);
    lcdBufferSetHLine(0, 0, LCD_COLS - 1, 7); 
    lcdBufferPrintString(0, "Sent packets:", 0, 2);
    lcdBufferPrintInt(0, (int32)(++packetCounter), 80, 2);
    lcdBufferPrintString(0, "Packet TX", 0, 7);
    lcdBufferSetHLine(0, 0, LCD_COLS - 1, 55);
    lcdBufferInvertPage(0, 0, LCD_COLS, 7);
    lcdSendBuffer(0);
}


/******************************************************************************
 * @fn          initMCU
 *
 * @brief       Initialize MCU and board peripherals
 *                
 * @param       none
 *
 * @return      none
 */
static void initMCU(void) {
  
    // Stop watchdog timer to prevent time out reset
    WDTCTL = WDTPW + WDTHOLD;
  
    // Initialize all GPIO configurations
    halBoardInit();
  
    // Care must be taken when handling power modes
    // - Peripheral units can request clocks and have them granted even if
    //   the system is in a power mode. Peripheral clock request is enabled
    //   as default.
    // - Simple Link only needs ACLK to be enabled to timers
    //   during power mode operation
    halMcuDisablePeripheralClockRequest((MCLKREQEN+SMCLKREQEN));

    // SPI flash uses same SPI interface as LCD -- we'll disable the SPI flash
    P8SEL &= BIT6; // ioflash_csn = gp
    P8DIR |= BIT6; // tpflash_csn = out
    P8OUT |= BIT6; // flash_csn = 1  
  
    // Init leds 
    halLedInit();

    // Init Buttons
    halButtonsInit();
    halButtonsInterruptEnable();

    // Init LCD
    lcdInit();

    // Instantiate tranceiver RF spi interface to SCLK ~ 4 MHz
    // input clockDivider - SMCLK/clockDivider gives SCLK frequency
    trxRfSpiInterfaceInit(0x02);

    // Enable global interrupt
    _BIS_SR(GIE);
}


/*******************************************************************************
* @fn           registerConfig
*
* @brief        Write register settings as given by SmartRF Studio
*
* @param        none
*
* @return       none
*/
static void registerConfig(void) {
  
    uint8 writeByte;
  
    // Reset radio
    trxSpiCmdStrobe(CC112X_SRES);
  
    // Write registers to radio
    for(uint16 i = 0; i < (sizeof  preferredSettings/sizeof(registerSetting_t)); i++) {
        writeByte =  preferredSettings[i].data;
        cc112xSpiWriteReg(preferredSettings[i].addr, &writeByte, 1);
    }
}


/******************************************************************************
 * @fn          manualCalibration
 *
 * @brief       Calibrates radio according to CC112x errata
 *                
 * @param       none
 *
 * @return      none
 */
#define VCDAC_START_OFFSET 2
#define FS_VCO2_INDEX 0
#define FS_VCO4_INDEX 1
#define FS_CHP_INDEX 2
static void manualCalibration(void) {
    uint8 original_fs_cal2;
    uint8 calResults_for_vcdac_start_high[3];
    uint8 calResults_for_vcdac_start_mid[3];
    uint8 marcstate;
    uint8 writeByte;
    
    // 1) Set VCO cap-array to 0 (FS_VCO2 = 0x00)
    writeByte = 0x00;
    cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
    
    // 2) Start with high VCDAC (original VCDAC_START + 2):
    cc112xSpiReadReg(CC112X_FS_CAL2, &original_fs_cal2, 1);
    writeByte = original_fs_cal2 + VCDAC_START_OFFSET;
    cc112xSpiWriteReg(CC112X_FS_CAL2, &writeByte, 1);
    
    // 3) Calibrate and wait for calibration to be done
    // (radio back in IDLE state)
    trxSpiCmdStrobe(CC112X_SCAL);
    
    do {
        cc112xSpiReadReg(CC112X_MARCSTATE, &marcstate, 1);
    } while (marcstate != 0x41);
    
    // 4) Read FS_VCO2, FS_VCO4 and FS_CHP register obtained with
    // high VCDAC_START value
    cc112xSpiReadReg(CC112X_FS_VCO2, &calResults_for_vcdac_start_high[FS_VCO2_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_VCO4, &calResults_for_vcdac_start_high[FS_VCO4_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_CHP, &calResults_for_vcdac_start_high[FS_CHP_INDEX], 1);
    
    // 5) Set VCO cap-array to 0 (FS_VCO2 = 0x00)
    writeByte = 0x00;
    cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
    
    // 6) Continue with mid VCDAC (original VCDAC_START):
    writeByte = original_fs_cal2;
    cc112xSpiWriteReg(CC112X_FS_CAL2, &writeByte, 1);
    
    // 7) Calibrate and wait for calibration to be done (radio back in IDLE state)
    trxSpiCmdStrobe(CC112X_SCAL);
    
    do {
        cc112xSpiReadReg(CC112X_MARCSTATE, &marcstate, 1);
    } while (marcstate != 0x41);
    
    // 8) Read FS_VCO2, FS_VCO4 and FS_CHP register obtained with mid VCDAC_START value
    cc112xSpiReadReg(CC112X_FS_VCO2, &calResults_for_vcdac_start_mid[FS_VCO2_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_VCO4, &calResults_for_vcdac_start_mid[FS_VCO4_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_CHP, &calResults_for_vcdac_start_mid[FS_CHP_INDEX], 1);
    
    // 9) Write back highest FS_VCO2 and corresponding FS_VCO and FS_CHP result
    if (calResults_for_vcdac_start_high[FS_VCO2_INDEX] > calResults_for_vcdac_start_mid[FS_VCO2_INDEX]) {
        writeByte = calResults_for_vcdac_start_high[FS_VCO2_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_high[FS_VCO4_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO4, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_high[FS_CHP_INDEX];
        cc112xSpiWriteReg(CC112X_FS_CHP, &writeByte, 1);
    } else {
        writeByte = calResults_for_vcdac_start_mid[FS_VCO2_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_mid[FS_VCO4_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO4, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_mid[FS_CHP_INDEX];
        cc112xSpiWriteReg(CC112X_FS_CHP, &writeByte, 1);
    }
}

/*******************************************************************************
Copyright 2011 Texas Instruments Incorporated. All rights reserved.

IMPORTANT: Your use of this Software is limited to those specific rights
granted under the terms of a software license agreement between the user
who downloaded the software, his/her employer (which must be your employer)
and Texas Instruments Incorporated (the "License").  You may not use this
Software unless you agree to abide by the terms of the License. The License
limits your use, and you acknowledge, that the Software may not be modified,
copied or distributed unless embedded on a Texas Instruments microcontroller
or used solely and exclusively in conjunction with a Texas Instruments radio
frequency transceiver, which is integrated into your product.  Other than for
the foregoing purpose, you may not use, reproduce, copy, prepare derivative
works of, modify, distribute, perform, display or sell this Software and/or
its documentation for any purpose.

YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

Should you have any questions regarding your right to use this Software,
contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/