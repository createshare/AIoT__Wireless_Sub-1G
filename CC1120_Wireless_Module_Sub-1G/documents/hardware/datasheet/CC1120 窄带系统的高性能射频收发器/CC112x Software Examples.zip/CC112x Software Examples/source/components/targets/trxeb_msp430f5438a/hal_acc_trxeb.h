/**************************************************************************//**
  @file     hal_acc_trxeb.h

  @brief    Accelerometer HAL header file.

******************************************************************************/
#ifndef HAL_ACC_TRXEB_H
#define HAL_ACC_TRXEB_H

/******************************************************************************
 * INCLUDES
 */
#include <hal_types.h>
#include <hal_acc.h>            // Include generic HAL API

 /*****************************************************************************
 * DEFINES
 */
// Accelerometer SPI (MOSI, MISO, CLK)
#define ACC_PORT_SPI_SEL        P9SEL
#define ACC_PORT_SPI_DIR        P9DIR
#define ACC_PORT_SPI_OUT        P9OUT
#define ACC_PORT_SPI_REN        P9REN

// Accelerometer CSn
#define ACC_PORT_CS_SEL         P8SEL
#define ACC_PORT_CS_DIR         P8DIR
#define ACC_PORT_CS_OUT         P8OUT

// Accelerometer interrupt
#define ACC_PORT_INT_SEL        P2SEL
#define ACC_PORT_INT_DIR        P2DIR
#define ACC_PORT_INT_OUT        P2OUT

// Accelerometer power
#define ACC_PORT_PWR_SEL        P6SEL
#define ACC_PORT_PWR_DIR        P6DIR
#define ACC_PORT_PWR_OUT        P6OUT

// Pins
#define ACC_INT_PIN             BIT0        // P2.0
#define ACC_CS_PIN              BIT7        // P8.7
#define ACC_PWR_PIN             BIT0        // P6.0
#define ACC_MOSI_PIN            BIT4        // P9.4
#define ACC_MISO_PIN            BIT5        // P9.5
#define ACC_CLK_PIN             BIT0        // P9.0

// CMA3000 Registers
#define ACC_WHO_AM_I            (0x00<<2)   // Identification register
#define ACC_REVID               (0x01<<2)   // ASIC revision ID, fixed in metal
#define ACC_CTRL                (0x02<<2)   // Configuration (por, operation modes)
#define ACC_STATUS              (0x03<<2)   // Status (por, EPROM parity)
#define ACC_RSTR                (0x04<<2)   // Reset register
#define ACC_INT_STATUS          (0x05<<2)   // Interrupt status register
#define ACC_DOUTX               (0x06<<2)   // X channel output data register
#define ACC_DOUTY               (0x07<<2)   // Y channel output data register
#define ACC_DOUTZ               (0x08<<2)   // Z channel output data register
#define ACC_MDTHR               (0x09<<2)   // Motion detection threshold value register
#define ACC_MDFFTMR             (0x0A<<2)   // Free fall and motion detection time register
#define ACC_FFTHR               (0x0B<<2)   // Free fall threshold value register
#define ACC_I2C_ADDR            (0x0C<<2)   // I2C device address

// CMA3000 Control Register setup
#define ACC_G_RANGE_2           0x80        // 2g range
#define ACC_INT_LEVEL_LOW       0x40        // INT active high
#define ACC_MDET_NO_EXIT        0x20        // Remain in motion detection mode
#define ACC_I2C_DIS             0x10        // I2C disabled
#define ACC_MODE_PD             0x00        // Power Down
#define ACC_MODE_100            0x02        // Measurement mode 100 Hz ODR
#define ACC_MODE_400            0x04        // Measurement mode 400 Hz ODR
#define ACC_MODE_40             0x06        // Measurement mode 40 Hz ODR
#define ACC_MODE_MD_10          0x08        // Motion detection mode 10 Hz ODR
#define ACC_MODE_FF_100         0x0A        // Free fall detection mode 100 Hz ODR
#define ACC_MODE_FF_400         0x0C        // Free fall detection mode 400 Hz ODR
#define ACC_INT_DIS             0x01        // Interrupts enabled

/******************************************************************************
* MACROS
*/
#define ACC_SPI_BEGIN()     st( ACC_PORT_CS_OUT &= ~(ACC_CS_PIN); ) // CSn low
#define ACC_SPI_END()       st( ACC_PORT_CS_OUT |=  (ACC_CS_PIN); ) // CSn high
#define ACC_SPI_RX()        UCA2RXBUF
#define ACC_SPI_TX(x)       st( UCA2TXBUF = (x); )
#define ACC_SPI_TXRX(x,y)   st( ACC_SPI_TX(x); ACC_SPI_WAIT(); (y)= ACC_SPI_RX(); )
#define ACC_SPI_WAIT_RX()   st( while(!(UCA2IFG & UCRXIFG)); ) // Wait until data is received
#define ACC_SPI_WAIT_TX()   st( while(!(UCA2IFG & UCTXIFG)); ) // Wait until TX buffer is ready for new data

#define ACC_PWR_ENABLE()    st( ACC_PORT_PWR_SEL &= ~(ACC_PWR_PIN); \
                                ACC_PORT_PWR_OUT |= ACC_PWR_PIN;    \
                                ACC_PORT_PWR_DIR |= ACC_PWR_PIN;    \
                              )
#define ACC_PWR_DISABLE()   st( ACC_PORT_PWR_OUT &= ~(ACC_PWR_PIN); )


/*****************************************************************************
 * VARIABLES
 */

 /****************************************************************************
 * FUNCTIONS
 */
// Functions in addition to those in the generic hal_acc.h
uint8 halAccGetRev(void);
uint8 halAccWriteReg(uint8 address, uint8 data);
uint8 halAccReadReg(uint8 address);


/****************************************************************************/
#endif // #ifndef


/****************************************************************************
  Copyright 2011 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*****************************************************************************/

