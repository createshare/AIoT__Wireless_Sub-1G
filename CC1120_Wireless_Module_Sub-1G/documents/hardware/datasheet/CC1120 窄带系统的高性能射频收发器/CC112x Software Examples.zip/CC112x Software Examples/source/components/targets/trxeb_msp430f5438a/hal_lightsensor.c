/**************************************************************************//**
    @file       hal_lightsensor.c

    @brief      Light sensor HAL on SmartRF TrxEB.

******************************************************************************/

/******************************************************************************
* INCLUDES
*/
#include <hal_lightsensor.h>
#include <hal_msp430.h>


/******************************************************************************
* DEFINES
*/
#define ALS_ADC_CHANNEL     ADC12INCH_2 // A2 <-> pin 6.2


/******************************************************************************
* MACROS
*/
#define ALS_POWER_ENABLE()  MCU_IO_OUTPUT(HAL_BOARD_IO_ALS_PWR_PORT,HAL_BOARD_IO_ALS_PWR_PIN,1)
#define ALS_POWER_DISABLE() st( MCU_IO_SET_LOW(HAL_BOARD_IO_ALS_PWR_PORT,HAL_BOARD_IO_ALS_PWR_PIN); \
                                MCU_IO_INPUT(HAL_BOARD_IO_ALS_PWR_PORT,HAL_BOARD_IO_ALS_PWR_PIN,MCU_IO_PULLDOWN); \
                              ) // Pull PWR low, then set as input pulldown.


/******************************************************************************
* FUNCTIONS
*/

/**************************************************************************//**
* @fn       halLightSensorInit(void)
*
* @brief    Turns on and initializes ADC12, to sample analog input
*           from ambient light sensor (ALS). Uses external AVcc/AVss as
*           ADC voltage reference.
*
* @param    none
*
* @return   none
******************************************************************************/
void halLightSensorInit(void)
{
    // Power the ambient light sensor (ALS_PWR pin to output high)
    ALS_POWER_ENABLE();

    // Set ALS_OUT pin (ADC ch. 2) as input with peripheral function
    MCU_IO_PERIPHERAL(HAL_BOARD_IO_ALS_OUT_PORT,HAL_BOARD_IO_ALS_OUT_PIN);

    // Configure ADC12
    ADC12CTL0 &= ~(ADC12ENC); // Disable conversion (to enable config of ADC12)
    ADC12CTL0 = ADC12SHT02 + ADC12ON;                       // SHT=64cycles, enable 2.5 V internal ref., turn ADC12 on
    ADC12CTL1 = ADC12SHP + ADC12SSEL_1 + ADC12CONSEQ_0;     // Use sampling timer, source clock = ACLK, single channel/single conv
    ADC12CTL2 = ADC12TCOFF + ADC12RES_2;                    // turn off temp sensor, 12 bit resolution, data in unsigned format

    ADC12MCTL0 = ALS_ADC_CHANNEL + ADC12EOS + ADC12SREF_0;  // Set input ch. to A2, this ch. is end of sequence, use AVcc and AVss as references

    // Allow the light sensor to settle before sampling any data (~11ms assuming 18MHz MCLK)
    __delay_cycles(200000);

} // halLightSensorInit

/**************************************************************************//**
* @fn       halLightSensorUninit(void)
*
* @brief    Turns off power to the Ambient Light Sensor and disables the ADC.
*
* @param    none
*
* @return   none
******************************************************************************/
void  halLightSensorUninit(void)
{
    // Disable ADC12
    ADC12CTL0 &= ~(ADC12ON);

    // Set ALS power to output low
    ALS_POWER_DISABLE();

} // halLightSensorUninit


/**************************************************************************//**
* @fn       halLightSensorRead(void)
*
* @brief    Enables ADC conversion and returns value when converted.
*
* @param    none
*
* @return   Returns the converted ADC value in ADC12MEM0 register.
******************************************************************************/
uint16 halLightSensorRead(void)
{
    ADC12IFG &= ~(BIT0);        // Clear pending memory register 0 flag

    ADC12CTL0 |=  (ADC12ENC | ADC12SC); // Enable and start conversion
    while( !(ADC12IFG & BIT0) );        // Wait for conversion to finish
    ADC12CTL0 &= ~(ADC12ENC | ADC12SC); // Stop/disable conversion

    return (uint16)ADC12MEM0;   // Return converted value

} // halLightSensorRead


/******************************************************************************
  Copyright 2011 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
******************************************************************************/

