/******************************************************************************
    Filename: cc112x_easy_link_reg_config.h  
    
    Description: Template for CC112x register export from SmartRF Studio 
                 
*******************************************************************************/
#ifndef CC112X_EASY_LINK_REG_CONFIG_H
#define CC112X_EASY_LINK_REG_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif
/******************************************************************************
 * INCLUDES
 */
#include "hal_spi_rf_trxeb.h"
#include "cc112x_spi.h"
  
/******************************************************************************
 * FUNCTIONS
 */  
  
// Carrier frequency = 868.000000 
// Symbol rate = 1.2 
// Bit rate = 1.2 
// Deviation = 3.997803 
// Manchester enable = false 
// Bit rate = 1.2 
// Modulation format = 2-FSK 
// Bit rate = 1.2 
// RX filter BW = 25.000000 
// TX power = -6 
// PA ramping = true 
// Packet length mode = Variable 
// Whitening = false 
// Address config = No address check. 
// Packet length = 255 
// Device address = 0 
static const registerSetting_t preferredSettings[] = {
  {CC112X_IOCFG3,        0xB0},
  {CC112X_IOCFG2,        0x06},
  {CC112X_IOCFG1,        0xB0},
  {CC112X_IOCFG0,        0xB0},
  {CC112X_SYNC_CFG1,     0x0B},
  {CC112X_DCFILT_CFG,    0x1C},
  {CC112X_IQIC,          0xC6},
  {CC112X_CHAN_BW,       0x08},
  {CC112X_MDMCFG0,       0x05},
  {CC112X_AGC_REF,       0x20},
  {CC112X_AGC_CS_THR,    0x19},
  {CC112X_AGC_CFG1,      0xA9},
  {CC112X_AGC_CFG0,      0xCF},
  {CC112X_FIFO_CFG,      0x00},
  {CC112X_SETTLING_CFG,  0x03},
  {CC112X_FS_CFG,        0x12},
  {CC112X_PKT_CFG1,      0x05},  
  {CC112X_PKT_CFG0,      0x20},
  {CC112X_PA_CFG2,       0x4F},
  {CC112X_PA_CFG1,       0x56},
  {CC112X_PA_CFG0,       0x1C},
  {CC112X_PKT_LEN,       0xFF},
  {CC112X_IF_MIX_CFG,    0x00},
  {CC112X_FREQOFF_CFG,   0x22},
  {CC112X_FREQ2,         0x6C},
  {CC112X_FREQ1,         0x80},
  {CC112X_FREQ0,         0x00},
  {CC112X_FS_DIG1,       0x00},
  {CC112X_FS_DIG0,       0x5F},
  {CC112X_FS_CAL0,       0x0E},
  {CC112X_FS_DIVTWO,     0x03},
  {CC112X_FS_DSM0,       0x33},
  {CC112X_FS_DVC0,       0x17},
  {CC112X_FS_PFD,        0x50},
  {CC112X_FS_PRE,        0x6E},
  {CC112X_FS_REG_DIV_CML,0x14},
  {CC112X_FS_SPARE,      0xAC},
  {CC112X_XOSC5,         0x0E},
  {CC112X_XOSC3,         0xC7},
  {CC112X_XOSC1,         0x07},
};

#ifdef  __cplusplus
}
#endif
/******************************************************************************
  Copyright 2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/
#endif