/******************************************************************************
  Filename:        cc112x_easy_link_rx.c
  
  Description:    This program sets up an easy link between two trxEB's with
                  CC112x EM's connected. 
                  The program can take any recomended register settings exported
                  from SmartRF Studio 7 without any modification with exeption 
                  from the assumtions decribed below.
  
  Notes:          The following asumptions must be fulfilled for the program
                  to work:
                  
                  1. GPIO2 has to be set up with GPIO2_CFG = 0x06
                     PKT_SYNC_RXTX for correct interupt
                  2. Packet engine has to be set up with status bytes enabled 
                     PKT_CFG1.APPEND_STATUS = 1
  
******************************************************************************/


/*****************************************************************************
* INCLUDES
*/
#include "msp430.h"
#include "hal_board.h"
#include "hal_mcu.h"
#include "hal_led_trxeb.h"
#include "hal_button_trxeb.h"
#include "lcd_dogm128_6.h"    
#include "hal_spi_rf_trxeb.h"
#include "hal_int_rf_trxeb.h"
#include "cc112x_spi.h"
#include "cc112x_easy_link_reg_config.h"

/******************************************************************************
 * CONSTANTS
 */ 

/******************************************************************************
* DEFINES
*/
#define ISR_ACTION_REQUIRED 1
#define ISR_IDLE            0

#define RX_FIFO_ERROR       0x11

/******************************************************************************
* LOCAL VARIABLES
*/
static uint8  packetSemaphore;
static uint32 packetCounter = 0;

/******************************************************************************
* STATIC FUNCTIONS
*/
static void initMCU(void);
static void registerConfig(void);
static void manualCalibration(void);
static void runRX(void);
static void radioRxTxISR(void);
static void updateLcd(void);

/******************************************************************************
 * @fn          main
 *
 * @brief       Runs the main routine
 *                
 * @param       none
 *
 * @return      none
 */
void main(void){
  
  // Initialize MCU and peripherals
  initMCU();
  
  // Write radio registers
  registerConfig();

  // Enter runRX, never coming back
  runRX();

}
/******************************************************************************
 * @fn          runRX
 *
 * @brief       puts radio in RX and waits for packets. Function assumes
 *              that status bytes are appended in the RX_FIFO
 *              Update packet counter and display for each packet received.
 *                
 * @param       none
 *
 * @return      none
 */
static void runRX(void){
  
  uint8 rxBuffer[128] = {0};
  uint8 rxBytes;
  uint8 marcStatus;
  
  // Connect ISR function to GPIO2, interrupt on falling edge
  trxIsrConnect(GPIO_2, FALLING_EDGE, &radioRxTxISR);
  
  // Enable interrupt from GPIO_2
  trxEnableInt(GPIO_2);
   
  // Update LCD
  updateLcd();
  
  // Calibrate radio according to errata
  manualCalibration();
    
  // Set radio in RX
  trxSpiCmdStrobe(CC112X_SRX);

  // Infinite loop
  while(TRUE){
    
    // Wait for packet received interrupt 
    if(packetSemaphore == ISR_ACTION_REQUIRED){
      
      // Read number of bytes in rx fifo
      cc112xSpiReadReg(CC112X_NUM_RXBYTES, &rxBytes, 1);
      
      // Check that we have bytes in fifo
      if(rxBytes != 0){
        
        // Read marcstate to check for RX FIFO error
        cc112xSpiReadReg(CC112X_MARCSTATE, &marcStatus, 1);
        
        // Mask out marcstate bits and check if we have a RX FIFO error
        if((marcStatus & 0x1F) == RX_FIFO_ERROR){
          
          // Flush RX Fifo
          trxSpiCmdStrobe(CC112X_SFRX);
        }
        else{
        
          // Read n bytes from rx fifo
          cc112xSpiReadRxFifo(rxBuffer, rxBytes);  
          
          // Check CRC ok (CRC_OK: bit7 in second status byte)
          // This assumes status bytes are appended in RX_FIFO
          // (PKT_CFG1.APPEND_STATUS = 1.)
          // If CRC is disabled the CRC_OK field will read 1
          if(rxBuffer[rxBytes-1] & 0x80){
            
            // Update packet counter
            packetCounter++;
          }
        }
      }
      
      // Update LCD
      updateLcd();
      
      // Reset packet semaphore
      packetSemaphore = ISR_IDLE;
      
      // Set radio back in RX
      trxSpiCmdStrobe(CC112X_SRX);
      
    }
  } 
}
/*******************************************************************************
* @fn          radioRxTxISR
*
* @brief       ISR for packet handling in RX. Sets packet semaphore 
*              and clears isr flag.
*
* @param       none
*
* @return      none
*/
static void radioRxTxISR(void){

  // Set packet semaphore
  packetSemaphore = ISR_ACTION_REQUIRED;  
  
  // Clear isr flag
  trxClearIntFlag(GPIO_2);
}
/******************************************************************************
 * @fn          initMCU
 *
 * @brief       Initialize MCU and board peripherals
 *                
 * @param       input, output parameters
 *
 * @return      describe return value, if any
 */
static void initMCU(void){
  
  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD;
  
  // Initialize all GPIO configurations
  halBoardInit();
  
  // Care must be taken when handling power modes
  // - Peripheral units can request clocks and have them granted even if
  //   the system is in a power mode. Peripheral clock request is enabled
  //   as default.
  // - Easy Link only needs ACLK to be enabled to timers
  //   during power mode operation
  halMcuDisablePeripheralClockRequest((MCLKREQEN+SMCLKREQEN));

  // SPI flash uses same SPI interface as LCD -- we'll disable the SPI flash
  P8SEL &= BIT6; // ioflash_csn = gp. 
  P8DIR |= BIT6; // tpflash_csn = ouut.
  P8OUT |= BIT6; // flash_csn = 1.     
  
  // Init leds 
  halLedInit();

  // Init Buttons
  halButtonsInit();
  halButtonsInterruptEnable();

  // Init LCD
  lcdInit();

  // Instantiate tranceiver RF spi interface to SCLK ~ 4 MHz */
  //input clockDivider - SMCLK/clockDivider gives SCLK frequency
  trxRfSpiInterfaceInit(0x02);

  // Enable global interrupt
  _BIS_SR(GIE);
  
}
/*******************************************************************************
* @fn          registerConfig
*
* @brief       Write register settings as given by SmartRF Studio found in
*              cc112x_easy_link_reg_config.h
*
* @param       none
*
* @return      none
*/
static void registerConfig(void){
  
  uint8 writeByte;
  
  // Reset radio
  trxSpiCmdStrobe(CC112X_SRES);
  
  // Write registers to radio
  for(uint16 i = 0; i < (sizeof  preferredSettings/sizeof(registerSetting_t)); i++) {
    writeByte =  preferredSettings[i].data;
    cc112xSpiWriteReg( preferredSettings[i].addr, &writeByte, 1);
  }
}
/******************************************************************************
 * @fn          updateLcd
 *
 * @brief       updates LCD buffer and sends bufer to LCD module.
 *                
 * @param       none
 *
 * @return      none
 */
static void updateLcd(void){
  
      // Update LDC buffer and send to screen.
      lcdBufferClear(0);
      lcdBufferPrintString(0, "    EasyLink Test    ", 0, 0);
      lcdBufferSetHLine(0, 0, LCD_COLS-1, 7); 
      lcdBufferPrintString(0, "Received ok:", 0, 3);
      lcdBufferPrintInt(0, packetCounter, 70, 4);
      lcdBufferPrintString(0, "      Packet RX        ", 0, 7);
      lcdBufferSetHLine(0, 0, LCD_COLS-1, 55);
      lcdBufferInvertPage(0, 0, LCD_COLS, 7);
      lcdSendBuffer(0);
}
/******************************************************************************
 * @fn          manualCalibration
 *
 * @brief       calibrates radio according to CC112x errata
 *                
 * @param       none
 *
 * @return      none
 */
#define VCDAC_START_OFFSET 2
#define FS_VCO2_INDEX 0
#define FS_VCO4_INDEX 1
#define FS_CHP_INDEX 2
static void manualCalibration(void){
  
    uint8 original_fs_cal2;
    uint8 calResults_for_vcdac_start_high[3];
    uint8 calResults_for_vcdac_start_mid[3];
    uint8 marcstate;
    uint8 writeByte;
    
    // 1) Set VCO cap-array to 0 (FS_VCO2 = 0x00)
    writeByte = 0x00;
    cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
    
    // 2) Start with high VCDAC (original VCDAC_START + 2):
    cc112xSpiReadReg(CC112X_FS_CAL2, &original_fs_cal2, 1);
    writeByte = original_fs_cal2 + VCDAC_START_OFFSET;
    cc112xSpiWriteReg(CC112X_FS_CAL2, &writeByte, 1);
    
    // 3) Calibrate and wait for calibration to be done (radio back in IDLE state)
    trxSpiCmdStrobe(CC112X_SCAL);
    
    do 
    {
        cc112xSpiReadReg(CC112X_MARCSTATE, &marcstate, 1);
    } while (marcstate != 0x41);
    
    // 4) Read FS_VCO2, FS_VCO4 and FS_CHP register obtained with high VCDAC_START value
    cc112xSpiReadReg(CC112X_FS_VCO2, &calResults_for_vcdac_start_high[FS_VCO2_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_VCO4, &calResults_for_vcdac_start_high[FS_VCO4_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_CHP, &calResults_for_vcdac_start_high[FS_CHP_INDEX], 1);
    
    // 5) Set VCO cap-array to 0 (FS_VCO2 = 0x00)
    writeByte = 0x00;
    cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
    
    // 6) Continue with mid VCDAC (original VCDAC_START):
    writeByte = original_fs_cal2;
    cc112xSpiWriteReg(CC112X_FS_CAL2, &writeByte, 1);
    
    // 7) Calibrate and wait for calibration to be done (radio back in IDLE state)
    trxSpiCmdStrobe(CC112X_SCAL);
    
    do 
    {
        cc112xSpiReadReg(CC112X_MARCSTATE, &marcstate, 1);
    } while (marcstate != 0x41);
    
    // 8) Read FS_VCO2, FS_VCO4 and FS_CHP register obtained with mid VCDAC_START value
    cc112xSpiReadReg(CC112X_FS_VCO2, &calResults_for_vcdac_start_mid[FS_VCO2_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_VCO4, &calResults_for_vcdac_start_mid[FS_VCO4_INDEX], 1);
    cc112xSpiReadReg(CC112X_FS_CHP, &calResults_for_vcdac_start_mid[FS_CHP_INDEX], 1);
    
    // 9) Write back highest FS_VCO2 and corresponding FS_VCO and FS_CHP result
    if (calResults_for_vcdac_start_high[FS_VCO2_INDEX] > calResults_for_vcdac_start_mid[FS_VCO2_INDEX]) 
    {
        writeByte = calResults_for_vcdac_start_high[FS_VCO2_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_high[FS_VCO4_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO4, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_high[FS_CHP_INDEX];
        cc112xSpiWriteReg(CC112X_FS_CHP, &writeByte, 1);
    }
    else 
    {
        writeByte = calResults_for_vcdac_start_mid[FS_VCO2_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO2, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_mid[FS_VCO4_INDEX];
        cc112xSpiWriteReg(CC112X_FS_VCO4, &writeByte, 1);
        writeByte = calResults_for_vcdac_start_mid[FS_CHP_INDEX];
        cc112xSpiWriteReg(CC112X_FS_CHP, &writeByte, 1);
    }
}
/***********************************************************************************
  Copyright 2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
***********************************************************************************/